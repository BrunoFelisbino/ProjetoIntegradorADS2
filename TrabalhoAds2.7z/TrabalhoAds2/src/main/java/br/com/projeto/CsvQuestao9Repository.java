package br.com.projeto;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvQuestao9Repository extends CrudRepository<CsvQuestao9, Integer> {
	
}