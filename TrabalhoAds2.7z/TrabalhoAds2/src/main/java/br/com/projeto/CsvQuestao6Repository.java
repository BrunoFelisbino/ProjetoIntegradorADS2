
package br.com.projeto;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CsvQuestao6Repository extends CrudRepository<CsvQuestao6, Integer> {

}
