package br.com.projeto;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvQuestao10Repository extends CrudRepository<CsvQuestao10, Integer> {
	
}