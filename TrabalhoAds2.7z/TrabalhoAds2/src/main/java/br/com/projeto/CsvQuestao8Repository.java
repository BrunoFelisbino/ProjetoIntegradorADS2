package br.com.projeto;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvQuestao8Repository extends CrudRepository<CsvQuestao8, Integer> {
	
}
