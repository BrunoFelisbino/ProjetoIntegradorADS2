package br.com.projeto;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CsvQuestao11Repository extends CrudRepository<CsvQuestao11, Integer> {
	
}